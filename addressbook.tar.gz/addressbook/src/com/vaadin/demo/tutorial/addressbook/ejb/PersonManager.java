package com.vaadin.demo.tutorial.addressbook.ejb;

import com.vaadin.demo.tutorial.addressbook.data.QueryMetaData;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.TransactionAttribute;

import com.vaadin.demo.tutorial.addressbook.data.Person;
import com.vaadin.demo.tutorial.addressbook.data.PersonReference;

@TransactionAttribute
@Local
public interface PersonManager {

    public List<PersonReference> getPersonReferences(QueryMetaData queryMetaData, String... propertyNames);

    public Person getPerson(Long id);

    public Person savePerson(Person person);
}
