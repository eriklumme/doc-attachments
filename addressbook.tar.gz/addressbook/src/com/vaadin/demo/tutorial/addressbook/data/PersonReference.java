package com.vaadin.demo.tutorial.addressbook.data;

import com.vaadin.data.Item;
import com.vaadin.data.Property;
import com.vaadin.data.util.ObjectProperty;
import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("serial")
public class PersonReference implements Serializable, Item {

    private Long personId;
    private Map<Object, Property> propertyMap;

    public PersonReference(Long personId, Map<String, Object> propertyMap) {
        this.personId = personId;
        this.propertyMap = new HashMap<Object, Property>();
        for (String key : propertyMap.keySet()) {
            this.propertyMap.put(key, new ObjectProperty(propertyMap.get(key)));
        }
    }

    public Long getPersonId() {
        return personId;
    }

    public Property getItemProperty(Object id) {
        return propertyMap.get(id);
    }

    public Collection<?> getItemPropertyIds() {
        return Collections.unmodifiableSet(propertyMap.keySet());
    }

    public boolean addItemProperty(Object id, Property property) throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Item is read-only.");
    }

    public boolean removeItemProperty(Object id) throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Item is read-only.");
    }
}
