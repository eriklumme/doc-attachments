package demoapp.security;

public class UserRoles {

	public static final String ROLE_DIRECTOR = "DIRECTOR";
	public static final String ROLE_PAYROLL_ASSISTANT = "PAYROLL_ASSISTANT";
	public static final String ROLE_PROJECT_MANAGER = "PROJECT_MANAGER";
	
}
